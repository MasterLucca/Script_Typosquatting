import socket
import whois
import requests
import pandas as pd
import json

# --------------------------------------------------------------------------
# IMPORTANTE: Insira sua chave da API do VirusTotal aqui
# Você pode obter uma gratuitamente em https://www.virustotal.com/
# --------------------------------------------------------------------------
VT_API_KEY = '651950158f01791ba13939fae07f1c211a1713d73de8686543e72805581f73b6'

# Ler a lista de domínios de um arquivo TXT
try:
    with open('dominios.txt', 'r') as arquivo:
        dominios = [linha.strip() for linha in arquivo.readlines()]
except FileNotFoundError:
    print("Erro: O arquivo 'dominios.txt' não foi encontrado.")
    print("Por favor, crie este arquivo e adicione um domínio por linha.")
    exit()

# Criar uma lista para armazenar os resultados
resultados = []

# --- Funções de Consulta ---

def verificar_status(dominio):
    """Verifica se o domínio resolve para um IP."""
    try:
        resultado = socket.gethostbyname(dominio)
        return "Ativo", resultado
    except socket.gaierror:
        return "Inativo", None

def consultar_whois(dominio):
    """Consulta informações WHOIS completas do domínio."""
    try:
        # Retorna o objeto WHOIS completo
        info = whois.whois(dominio)
        return info
    except Exception as e:
        return f"Erro ao consultar WHOIS: {str(e)}"

def consultar_asn(ip):
    """Consulta o ASN do IP usando a API do ipinfo.io."""
    if not ip:
        return "Não aplicável"
    try:
        # Recomenda-se não deixar tokens hardcoded, mas mantendo o padrão do seu código
        url = f"https://ipinfo.io/{ip}/json?token=52f7413fa5f040"
        response = requests.get(url, timeout=5)
        response.raise_for_status() # Lança um erro para status HTTP ruins (4xx ou 5xx)
        data = response.json()
        if 'asn' in data and data.get('asn'):
             return f"{data.get('asn', {}).get('asn', '')} - {data.get('asn', {}).get('name', '')}"
        return "ASN não disponível"
    except requests.RequestException as e:
        return f"Erro de conexão: {e}"
    except Exception as e:
        return str(e)

def obter_codigo_status(dominio):
    """Obtém o código de status HTTP/HTTPS do domínio."""
    for protocol in ['https://', 'http://']:
        try:
            response = requests.head(f"{protocol}{dominio}", allow_redirects=True, timeout=5)
            return response.status_code
        except requests.RequestException:
            continue # Tenta o próximo protocolo se falhar
    return "Falha na conexão"

def consultar_virustotal(dominio):
    """Consulta a reputação do domínio na API do VirusTotal."""
    if VT_API_KEY == 'SUA_CHAVE_API_AQUI':
        return "Chave da API do VirusTotal não configurada"
        
    url = f'https://www.virustotal.com/api/v3/domains/{dominio}'
    headers = {
        'x-apikey': VT_API_KEY
    }
    try:
        response = requests.get(url, headers=headers, timeout=10)
        if response.status_code == 200:
            data = response.json()
            stats = data['data']['attributes']['last_analysis_stats']
            malicious_count = stats.get('malicious', 0)
            
            if malicious_count > 0:
                return f"Flag maliciosa reportada ({malicious_count} detecções)"
            else:
                return "Nenhuma Flag maliciosa reportada"
        elif response.status_code == 404:
            return "Domínio não encontrado no VirusTotal"
        else:
            return f"Erro na API VT: {response.status_code}"
            
    except requests.RequestException as e:
        return f"Erro de conexão com VT: {e}"
    except Exception as e:
        return f"Erro inesperado: {str(e)}"

# --- Loop Principal ---
print(f"Iniciando a análise de {len(dominios)} domínios...")

for i, dominio in enumerate(dominios):
    print(f"({i+1}/{len(dominios)}) Analisando: {dominio}")
    
    status, ip = verificar_status(dominio)
    info_whois = consultar_whois(dominio)
    codigo_status = obter_codigo_status(dominio)
    reputacao_vt = consultar_virustotal(dominio)
    
    asn = consultar_asn(ip)

    # Para garantir que o WHOIS completo seja salvo corretamente, convertemos para string
    # Isso coloca todos os dados do WHOIS em uma única célula no Excel.
    whois_str = str(info_whois)

    resultado = {
        "Domínio": dominio,
        "Status": f"{status} (HTTP: {codigo_status})",
        "IP": ip if ip else "Não disponível",
        "Reputação VirusTotal": reputacao_vt,
        "ASN": asn,
        "WHOIS Completo": whois_str, # Coluna com o WHOIS completo
    }
    resultados.append(resultado)

# Converter a lista de resultados em um DataFrame
df = pd.DataFrame(resultados)

# Salvar o DataFrame em um arquivo Excel (XLSX)
output_filename = 'informacoes_dominios.xlsx'
df.to_excel(output_filename, index=False)

print("-" * 50)
print(f"Análise concluída! As informações foram salvas em '{output_filename}'.")